const AWS = require('aws-sdk');

// SQS 및 SNS 클라이언트 생성
const sqs = new AWS.SQS({ region: 'ap-northeast-1' });

exports.handler = async (event) => {

};